
document.getElementById("root").innerHTML = "<h1>Guia de Investimentos</h1><p>Site carregado com sucesso no GitHub Pages.</p>";
